for P in [True, False]:
    print(P, not P)

'''
True False
False True
'''
