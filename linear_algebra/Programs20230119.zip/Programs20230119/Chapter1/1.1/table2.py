for P in [True, False]:
    for Q in [True, False]:
        print(P, Q, P and Q, P or Q, P <= Q , P == Q)
        
'''
True True True True True True
True False False True False False
False True False True True False
False False False False True True
'''
