ThinkPython
===========

LaTeX source, code examples, and exercise solutions for Think Python, 2nd edition, by Allen Downey.

You can download this book in PDF from [Green Tea Press](http://greenteapress.com/wp/think-python-2e/) or buy it in paper and other formats from [O'Reilly Media](http://shop.oreilly.com/product/0636920045267.do).

To build the book from source you will need a LaTeX installion.  I recommend the TeX Live distribution with the following packages:

* texlive-latex-base
* texlive-latex-extra
* texlive-fonts-recommended

