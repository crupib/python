#!/usr/bin/env python3

"""Solution to chapter 8, exercise 37, beyond 3: stuff"""

__all__ = ['a', 'c', 'bar']

a = 100

b = [10, 20, 30]

c = {'a': 1, 'b': 2, 'c': 3}


def foo():
    return 'Hello from foo!'


def bar():
    return 'Hello from bar!'
