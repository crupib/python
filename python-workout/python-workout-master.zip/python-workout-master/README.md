# Code files from "Python Workout"

My book, "Python Workout" (https://PythonWorkout.com/) contains 50 exercises that help to improve your Python fluency.  This repository contains the code and solutions to those exercises, including all of the "beyond the exercise" additional, bonus exercises.

The main exercises have "pytest" tests, while the "beyond" exercises don't.

While you're welcome to look at this code, you should *NOT* look at it before you work on a solution by yourself! You'll learn the most by actually putting in the work, and trying to solve the problems. Looking at the answer isn't nearly as useful to your learning.

Don't forget that my free, weekly "Better developers" newsletter (currently read by about 18,000 people) contains a new Python-related article each week. Sign up at https://BetterDevelopersWeekly.com/ .

Enjoy!

_Reuven_
