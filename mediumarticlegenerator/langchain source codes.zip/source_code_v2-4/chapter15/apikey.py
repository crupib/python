# apikey = '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'
apikey = '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'